# Discord Bot Status Changer [SKEETZ LEAKS]

Este trocador de status do bot Discord é um aplicativo JavaScript simples que permite alterar o status de presença do seu bot no Discord. Você pode personalizar o status do seu bot para exibir uma mensagem específica ou mostrar que ele está jogando um jogo específico.

## Usage

1. Clone ou baixe este repositório para sua máquina local ou faça um fork dele.

2. Instale as dependências necessárias usando npm ou yarn

   ```shell
   npm install
   ```
3. Adicione seu token em secrets


/**
            ██████  ██ ▄█▀▓█████ ▓█████▄▄▄█████▓▒███████▒ 
          ▒██    ▒  ██▄█▒ ▓█   ▀ ▓█   ▀▓  ██▒ ▓▒▒ ▒ ▒ ▄▀░   
          ░ ▓██▄   ▓███▄░ ▒███   ▒███  ▒ ▓██░ ▒░░ ▒ ▄▀▒░   
            ▒   ██▒▓██ █▄ ▒▓█  ▄ ▒▓█  ▄░ ▓██▓ ░   ▄▀▒   ░ 
          ▒██████▒▒▒██▒ █▄░▒████▒░▒████▒ ▒██▒ ░ ▒███████▒  
          ▒ ▒▓▒ ▒ ░▒ ▒▒ ▓▒░░ ▒░ ░░░ ▒░ ░ ▒ ░░   ░▒▒ ▓░▒░▒  
          ░ ░▒  ░ ░░ ░▒ ▒░ ░ ░  ░ ░ ░  ░   ░    ░░▒ ▒ ░ ▒   
          ░  ░  ░  ░ ░░ ░    ░      ░    ░      ░ ░ ░ ░ ░  
                ░  ░  ░      ░  ░   ░  ░          ░ ░       
                                                ░                  

  DISCORD SERVER : https://discord.gg/FUEHs7RCqz
 * **********************************************
 *   Code by SKEETZ
 * **********************************************
 */
